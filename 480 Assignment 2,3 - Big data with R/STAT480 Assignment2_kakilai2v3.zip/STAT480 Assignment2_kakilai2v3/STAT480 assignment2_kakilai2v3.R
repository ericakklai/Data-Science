## STAT 480 Homework 2##
setwd("/home/student/container-data/RDataScience/AirlineDelays")
# Code Reference: Code for lecture of STAT 480 Chapter 5

# Install package
installIfNeeded = function(cliblist){
  libsNeeded = cliblist
  libsNeeded = libsNeeded[!(libsNeeded %in% installed.packages()[,"Package"])]
  if(length(libsNeeded)>0) install.packages(libsNeeded)
}

installIfNeeded(c("RSQLite", "foreach", "parallel", "doSNOW", "ggplot2", "biganalytics", "bigmemory"))
library(biganalytics)
library(ggplot2)
library(reshape2)
library(corrplot)

#read data
x <- read.big.matrix("AirlineData0708.csv", header = TRUE, 
                     backingfile = "air0708.bin",
                     descriptorfile = "air0708.desc",
                     type = "integer")

#Q8
dow <- split(1:nrow(x), x[,"DayOfWeek"])


delay_byday = c()
delay_byday = foreach (day = dow, .combine = c) %do% {
  mean(x[day,"DepDelay"],na.rm = TRUE)
}

which.min(delay_byday)

# Create a variable to hold the quantile probabilities.
myProbs <- c(0.9, 0.99, 0.999, 0.9999)

# Find the quantiles for each hour.
delayQuantiles <- foreach( DO = dow, .combine=cbind) %do% {
  require(bigmemory)
  #x <- attach.big.matrix("air0708.desc")
  quantile(x[DO, "DepDelay"], myProbs, 
           na.rm = TRUE)
}
colnames(delayQuantiles) <- names(dow)
dq <- melt(delayQuantiles)
names(dq) <- c("percentile", "dw", "delay")
qplot(dw, delay, data = dq, color = percentile, geom = "line") +xlim("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

#Q9
dom <- split(1:nrow(x), x[,"DayofMonth"])


delay_bydaym = c()
delay_bydaym = foreach (day = dom, .combine = c) %do% {
  mean(x[day,"DepDelay"],na.rm = TRUE)
}

which.min(delay_bydaym)

# Create a variable to hold the quantile probabilities.
myProbs <- c(0.9, 0.99, 0.999, 0.9999)

# Find the quantiles for each hour.
delayQuantiles <- foreach( DO = dom, .combine=cbind) %do% {
  require(bigmemory)
  #x <- attach.big.matrix("air0708.desc")
  quantile(x[DO, "DepDelay"], myProbs, 
           na.rm = TRUE)
}
colnames(delayQuantiles) <- names(dom)
dq <- melt(delayQuantiles)
names(dq) <- c("percentile", "dm", "delay")
qplot(dm, delay, data = dq, color = percentile, geom = "line")

#Q14
blm <- biglm.big.matrix( ArrDelay ~ WeatherDelay, data = x )
summary(blm)

#Q15
formula = "ArrDelay ~ Year" 
for(header in colnames(x)) {
  if (header != "ArrDelay" && header != "CancellationCode" && header != "Year"){
    formula = paste(paste(formula, "+"), header)
  }
}
formula = as.formula(formula)
blm_all <- biglm.big.matrix( formula , data = x )

summary(blm_all)

#refit model with significant variables 
blm_re <- biglm.big.matrix(ArrDelay~DepDelay + ActualElapsedTime +CRSElapsedTime, data = x)
summary(blm_re)


