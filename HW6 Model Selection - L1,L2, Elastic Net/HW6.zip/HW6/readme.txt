Files:
HW6_code : code for HW 6
HW6_report : report for HW 6

How to Run HW6_Code:
Change the variables ‘filename1’ and ‘filename2’ to the directory of the data.